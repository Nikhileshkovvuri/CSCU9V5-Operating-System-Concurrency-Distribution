import java.net.*;
import java.io.*;
import java.util.*;

public class Bidder{

    private Random rnd;

    private ServerSocket in_ss;

    private Socket in_soc;
    private Socket out_soc;
     

    String	localhost = "127.0.0.1";
    String 	n_host_name;
    
    int 	in_port;
    int 	out_port;

    int         token;
 
       

    // BIDDER:
    // receives the token by a socket communication through in_port;
    // performs its auction algorithm: 
    //   - reads from bid.txt, 
    //   - decides whether to bit or not, 
    //   - in case of bidding, updates bid;
    // forwards the lottery token by a socket communication through out_port 



    public Bidder (int inpor, int outpor){
	
	rnd = new Random();
	in_port = inpor;
	out_port = outpor;

	RandomAccessFile current_bid;
	int the_bid;
	
    	System.out.println("Bidder  : " +in_port+ " of distributed lottry is active ....");
       


	try {
		
	// >>>
	// **** Wait for the token and receive it from a soket listening on the in_port;


	    
	// >>>
	// **** Perform the auction algorithm (with suitable delay/sleep of 1 sec);


	    try{Thread.sleep(1000);} catch (Exception e){}




	// >>>
	// **** Forward the the token through the  out_port;

	
	    System.out.println("Bidder  : " +in_port+ " - forwarded token to "+out_port);
	
	}
	catch (java.io.IOException e) {
	    System.out.println(e);
	    System.exit(1);	
	}
    }

    
        
    public static void main (String args[]){
	
	String n_host_name = ""; 
	int n_port;
	
	// receive own port and next port in the ring at launch time
	if (args.length != 2) {
	    System.out.print("Usage: Bidder [port number] [forward port number]");
	    System.exit(1);
	}
	
	// get the IP address of the node  - might be useful on multi-computer runs 
 	try{ 
	    InetAddress n_inet_address =  InetAddress.getLocalHost() ;
	    n_host_name = n_inet_address.getHostName();
	    System.out.println ("node hostname is " +n_host_name+":"+n_inet_address);
    	}
    	catch (java.net.UnknownHostException e){
	    System.out.println(e);
	    System.exit(1);
    	} 
	
    	Bidder b = new Bidder(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
    }
    
    
}

